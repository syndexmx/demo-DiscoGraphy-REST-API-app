package com.github.syndexmx.demodiscography;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemodiscographyApplicationTests {

	@Test
	void contextLoads() {
	}

}
