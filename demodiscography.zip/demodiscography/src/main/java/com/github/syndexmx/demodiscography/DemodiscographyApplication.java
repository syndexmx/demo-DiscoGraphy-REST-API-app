package com.github.syndexmx.demodiscography;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemodiscographyApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemodiscographyApplication.class, args);
	}

}
